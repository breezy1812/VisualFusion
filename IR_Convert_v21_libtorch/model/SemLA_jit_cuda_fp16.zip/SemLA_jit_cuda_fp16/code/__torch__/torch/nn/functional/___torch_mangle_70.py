def interpolate(input: Tensor,
    size: Optional[int]=None,
    scale_factor: Optional[float]=None,
    mode: str="nearest",
    align_corners: Optional[bool]=None,
    recompute_scale_factor: Optional[bool]=None,
    antialias: bool=False) -> Tensor:
  _0 = "align_corners option can only be set with the interpolating modes: linear | bilinear | bicubic | trilinear"
  _1 = "only one of size or scale_factor should be defined"
  _2 = "either size or scale_factor should be defined"
  _3 = "recompute_scale_factor is not meaningful with an explicit size."
  _4 = "Anti-alias option is only supported for bilinear and bicubic modes"
  _5 = __torch__.torch.nn.functional.adaptive_avg_pool2d
  _6 = __torch__.torch.nn.functional.adaptive_avg_pool3d
  _7 = "Got 3D input, but bilinear mode needs 4D input"
  _8 = "Got 3D input, but trilinear mode needs 5D input"
  _9 = "Got 4D input, but linear mode needs 3D input"
  _10 = "Got 4D input, but trilinear mode needs 5D input"
  _11 = "Got 5D input, but linear mode needs 3D input"
  _12 = "Got 5D input, but bilinear mode needs 4D input"
  _13 = "Input Error: Only 3D, 4D and 5D input Tensors supported (got {}D) for the modes: nearest | linear | bilinear | bicubic | trilinear | area | nearest-exact (got {})"
  _14 = uninitialized(Tensor)
  _15 = uninitialized(List[int])
  _16 = uninitialized(Optional[bool])
  _17 = uninitialized(NoneType)
  _18 = uninitialized(List[float])
  _19 = uninitialized(Optional[List[int]])
  _20 = uninitialized(Optional[List[float]])
  _21 = uninitialized(Optional[int])
  _22 = uninitialized(Optional[bool])
  _23 = uninitialized(bool)
  _24 = torch.__contains__(["nearest", "area", "nearest-exact"], mode)
  if _24:
    _25 = torch.__isnot__(align_corners, None)
    if _25:
      ops.prim.RaiseException(_0, "builtins.ValueError")
      align_corners1 : Optional[bool] = _22
    else:
      align_corners1 = align_corners
    align_corners0 : Optional[bool] = align_corners1
  else:
    if torch.__is__(align_corners, None):
      align_corners2 = False
    else:
      align_corners3 = unchecked_cast(bool, align_corners)
      align_corners2 = align_corners3
    align_corners0 = align_corners2
  dim = torch.sub(torch.dim(input), 2)
  if torch.__isnot__(size, None):
    size1 = unchecked_cast(int, size)
    _26, size0 = torch.__isnot__(scale_factor, None), size1
  else:
    _26, size0 = False, size
  if _26:
    ops.prim.RaiseException(_1, "builtins.ValueError")
    size2, output_size, scale_factors = _21, _19, _20
  else:
    if torch.__isnot__(size0, None):
      size4 = unchecked_cast(int, size0)
      if torch.__is__(scale_factor, None):
        pass
      else:
        ops.prim.RaiseException("AssertionError: ")
      size5 = unchecked_cast(int, size4)
      output_size1 = annotate(List[int], [])
      for _27 in range(dim):
        _28 = torch.append(output_size1, size5)
      size3, output_size0, scale_factors0 = size5, output_size1, None
    else:
      _29 = torch.__isnot__(scale_factor, None)
      if _29:
        scale_factor0 = unchecked_cast(float, scale_factor)
        if torch.__is__(size0, None):
          size7 : Optional[int] = size0
        else:
          ops.prim.RaiseException("AssertionError: ")
          size7 = _21
        scale_factor1 = unchecked_cast(float, scale_factor0)
        scale_factors2 = annotate(List[float], [])
        for _30 in range(dim):
          _31 = torch.append(scale_factors2, scale_factor1)
        size6, output_size2, scale_factors1 = size7, None, scale_factors2
      else:
        ops.prim.RaiseException(_2, "builtins.ValueError")
        size6, output_size2, scale_factors1 = _21, _17, _18
      size3, output_size0, scale_factors0 = size6, output_size2, scale_factors1
    size2, output_size, scale_factors = size3, output_size0, scale_factors0
  _32 = torch.__isnot__(recompute_scale_factor, None)
  if _32:
    recompute_scale_factor1 = unchecked_cast(bool, recompute_scale_factor)
    _33, recompute_scale_factor0 = recompute_scale_factor1, recompute_scale_factor1
  else:
    _33, recompute_scale_factor0 = False, recompute_scale_factor
  if _33:
    recompute_scale_factor3 = unchecked_cast(bool, recompute_scale_factor0)
    _34, recompute_scale_factor2 = torch.__isnot__(size2, None), recompute_scale_factor3
  else:
    _34, recompute_scale_factor2 = False, recompute_scale_factor0
  if _34:
    ops.prim.RaiseException(_3, "builtins.ValueError")
    recompute_scale_factor4 : Optional[bool] = _16
  else:
    recompute_scale_factor4 = recompute_scale_factor2
  if torch.eq(mode, "area"):
    _35 = torch.__is__(output_size, None)
  else:
    _35 = False
  if _35:
    recompute_scale_factor5 : Optional[bool] = True
  else:
    recompute_scale_factor5 = recompute_scale_factor4
  _36 = torch.__isnot__(recompute_scale_factor5, None)
  if _36:
    recompute_scale_factor6 = unchecked_cast(bool, recompute_scale_factor5)
    _37 = recompute_scale_factor6
  else:
    _37 = False
  if _37:
    _38 = torch.__isnot__(scale_factors, None)
    if _38:
      scale_factors5 = unchecked_cast(List[float], scale_factors)
      scale_factors4 = scale_factors5
    else:
      ops.prim.RaiseException("AssertionError: ")
      scale_factors4 = _18
    output_size4 = annotate(List[int], [])
    for i in range(dim):
      _39 = torch.size(input, torch.add(i, 2))
      _40 = torch.mul(float(_39), scale_factors4[i])
      _41 = torch.append(output_size4, torch.floor(_40))
    output_size3, scale_factors3 = output_size4, None
  else:
    output_size3, scale_factors3 = output_size, scale_factors
  if antialias:
    _43 = torch.__contains__(["bilinear", "bicubic"], mode)
    if _43:
      _44 = torch.eq(torch.dim(input), 4)
    else:
      _44 = False
    _42 = torch.__not__(_44)
  else:
    _42 = False
  if _42:
    ops.prim.RaiseException(_4, "builtins.ValueError")
  else:
    pass
  if torch.eq(torch.dim(input), 3):
    _45 = torch.eq(mode, "nearest")
  else:
    _45 = False
  if _45:
    _47 = torch.upsample_nearest1d(input, output_size3, scale_factors3)
    _46 = _47
  else:
    if torch.eq(torch.dim(input), 4):
      _48 = torch.eq(mode, "nearest")
    else:
      _48 = False
    if _48:
      _50 = torch.upsample_nearest2d(input, output_size3, scale_factors3)
      _49 = _50
    else:
      if torch.eq(torch.dim(input), 5):
        _51 = torch.eq(mode, "nearest")
      else:
        _51 = False
      if _51:
        _53 = torch.upsample_nearest3d(input, output_size3, scale_factors3)
        _52 = _53
      else:
        if torch.eq(torch.dim(input), 3):
          _55 = torch.eq(mode, "nearest-exact")
          _54 = _55
        else:
          _54 = False
        if _54:
          _57 = torch._upsample_nearest_exact1d(input, output_size3, scale_factors3)
          _56 = _57
        else:
          if torch.eq(torch.dim(input), 4):
            _59 = torch.eq(mode, "nearest-exact")
            _58 = _59
          else:
            _58 = False
          if _58:
            _61 = torch._upsample_nearest_exact2d(input, output_size3, scale_factors3)
            _60 = _61
          else:
            _62 = torch.eq(torch.dim(input), 5)
            if _62:
              _64 = torch.eq(mode, "nearest-exact")
              _63 = _64
            else:
              _63 = False
            if _63:
              _66 = torch._upsample_nearest_exact3d(input, output_size3, scale_factors3)
              _65 = _66
            else:
              _67 = torch.eq(torch.dim(input), 3)
              if _67:
                _68 = torch.eq(mode, "area")
              else:
                _68 = False
              if _68:
                _70 = torch.__isnot__(output_size3, None)
                if _70:
                  output_size6 = unchecked_cast(List[int], output_size3)
                  output_size5 = output_size6
                else:
                  ops.prim.RaiseException("AssertionError: ")
                  output_size5 = _15
                _71 = torch.adaptive_avg_pool1d(input, output_size5)
                _69 = _71
              else:
                _72 = torch.eq(torch.dim(input), 4)
                if _72:
                  _74 = torch.eq(mode, "area")
                  _73 = _74
                else:
                  _73 = False
                if _73:
                  _76 = torch.__isnot__(output_size3, None)
                  if _76:
                    output_size8 = unchecked_cast(List[int], output_size3)
                    output_size7 = output_size8
                  else:
                    ops.prim.RaiseException("AssertionError: ")
                    output_size7 = _15
                  _77 = _5(input, output_size7, )
                  _75 = _77
                else:
                  _78 = torch.eq(torch.dim(input), 5)
                  if _78:
                    _80 = torch.eq(mode, "area")
                    _79 = _80
                  else:
                    _79 = False
                  if _79:
                    _82 = torch.__isnot__(output_size3, None)
                    if _82:
                      output_size10 = unchecked_cast(List[int], output_size3)
                      output_size9 = output_size10
                    else:
                      ops.prim.RaiseException("AssertionError: ")
                      output_size9 = _15
                    _83 = _6(input, output_size9, )
                    _81 = _83
                  else:
                    _84 = torch.eq(torch.dim(input), 3)
                    if _84:
                      _86 = torch.eq(mode, "linear")
                      _85 = _86
                    else:
                      _85 = False
                    if _85:
                      _88 = torch.__isnot__(align_corners0, None)
                      if _88:
                        align_corners5 = unchecked_cast(bool, align_corners0)
                        align_corners4 = align_corners5
                      else:
                        ops.prim.RaiseException("AssertionError: ")
                        align_corners4 = _23
                      _89 = torch.upsample_linear1d(input, output_size3, align_corners4, scale_factors3)
                      _87 = _89
                    else:
                      _90 = torch.eq(torch.dim(input), 4)
                      if _90:
                        _92 = torch.eq(mode, "bilinear")
                        _91 = _92
                      else:
                        _91 = False
                      if _91:
                        _94 = torch.__isnot__(align_corners0, None)
                        if _94:
                          align_corners7 = unchecked_cast(bool, align_corners0)
                          align_corners6 = align_corners7
                        else:
                          ops.prim.RaiseException("AssertionError: ")
                          align_corners6 = _23
                        if antialias:
                          _96 = torch._upsample_bilinear2d_aa(input, output_size3, align_corners6, scale_factors3)
                          _95 = _96
                        else:
                          _97 = torch.upsample_bilinear2d(input, output_size3, align_corners6, scale_factors3)
                          _95 = _97
                        _93 = _95
                      else:
                        _98 = torch.dim(input)
                        _99 = torch.eq(_98, 5)
                        if _99:
                          _101 = torch.eq(mode, "trilinear")
                          _100 = _101
                        else:
                          _100 = False
                        if _100:
                          _103 = torch.__isnot__(align_corners0, None)
                          if _103:
                            align_corners9 = unchecked_cast(bool, align_corners0)
                            align_corners8 = align_corners9
                          else:
                            ops.prim.RaiseException("AssertionError: ")
                            align_corners8 = _23
                          _104 = torch.upsample_trilinear3d(input, output_size3, align_corners8, scale_factors3)
                          _102 = _104
                        else:
                          _105 = torch.dim(input)
                          _106 = torch.eq(_105, 4)
                          if _106:
                            _108 = torch.eq(mode, "bicubic")
                            _107 = _108
                          else:
                            _107 = False
                          if _107:
                            _110 = torch.__isnot__(align_corners0, None)
                            if _110:
                              align_corners11 = unchecked_cast(bool, align_corners0)
                              align_corners10 = align_corners11
                            else:
                              ops.prim.RaiseException("AssertionError: ")
                              align_corners10 = _23
                            if antialias:
                              _112 = torch._upsample_bicubic2d_aa(input, output_size3, align_corners10, scale_factors3)
                              _111 = _112
                            else:
                              _113 = torch.upsample_bicubic2d(input, output_size3, align_corners10, scale_factors3)
                              _111 = _113
                            _109 = _111
                          else:
                            _114 = torch.dim(input)
                            _115 = torch.eq(_114, 3)
                            if _115:
                              _117 = torch.eq(mode, "bilinear")
                              _116 = _117
                            else:
                              _116 = False
                            if _116:
                              ops.prim.RaiseException(_7, "builtins.NotImplementedError")
                            else:
                              pass
                            _118 = torch.dim(input)
                            _119 = torch.eq(_118, 3)
                            if _119:
                              _121 = torch.eq(mode, "trilinear")
                              _120 = _121
                            else:
                              _120 = False
                            if _120:
                              ops.prim.RaiseException(_8, "builtins.NotImplementedError")
                            else:
                              pass
                            _122 = torch.dim(input)
                            _123 = torch.eq(_122, 4)
                            if _123:
                              _125 = torch.eq(mode, "linear")
                              _124 = _125
                            else:
                              _124 = False
                            if _124:
                              ops.prim.RaiseException(_9, "builtins.NotImplementedError")
                            else:
                              pass
                            _126 = torch.dim(input)
                            _127 = torch.eq(_126, 4)
                            if _127:
                              _129 = torch.eq(mode, "trilinear")
                              _128 = _129
                            else:
                              _128 = False
                            if _128:
                              ops.prim.RaiseException(_10, "builtins.NotImplementedError")
                            else:
                              pass
                            _130 = torch.dim(input)
                            _131 = torch.eq(_130, 5)
                            if _131:
                              _133 = torch.eq(mode, "linear")
                              _132 = _133
                            else:
                              _132 = False
                            if _132:
                              ops.prim.RaiseException(_11, "builtins.NotImplementedError")
                            else:
                              pass
                            _134 = torch.dim(input)
                            _135 = torch.eq(_134, 5)
                            if _135:
                              _137 = torch.eq(mode, "bilinear")
                              _136 = _137
                            else:
                              _136 = False
                            if _136:
                              ops.prim.RaiseException(_12, "builtins.NotImplementedError")
                            else:
                              pass
                            _138 = torch.dim(input)
                            _139 = torch.format(_13, _138, mode)
                            ops.prim.RaiseException(_139, "builtins.NotImplementedError")
                            _109 = _14
                          _102 = _109
                        _93 = _102
                      _87 = _93
                    _81 = _87
                  _75 = _81
                _69 = _75
              _65 = _69
            _60 = _65
          _56 = _60
        _52 = _56
      _49 = _52
    _46 = _49
  return _46
