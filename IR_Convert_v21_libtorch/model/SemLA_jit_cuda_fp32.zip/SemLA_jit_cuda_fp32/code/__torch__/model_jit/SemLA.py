class SemLA(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  backbone : __torch__.model_jit.reg.SemLA_Reg
  def forward(self: __torch__.model_jit.SemLA.SemLA,
    img_vi: Tensor,
    img_ir: Tensor) -> Tuple[Tensor, Tensor]:
    _0 = __torch__.model_jit.utils.n_c_h_w_2_n_hw_c
    backbone = self.backbone
    _1 = (backbone).forward(torch.cat([img_vi, img_ir]), )
    feat_reg_vi_final, feat_reg_ir_final, feat_sa_vi, feat_sa_ir, = _1
    feat_reg_vi = _0(feat_reg_vi_final, )
    feat_reg_ir = _0(feat_reg_ir_final, )
    _2 = torch.pow((torch.size(feat_reg_vi))[-1], 0.5)
    feat_reg_vi0 = torch.div(feat_reg_vi, _2)
    _3 = torch.pow((torch.size(feat_reg_ir))[-1], 0.5)
    feat_reg_ir0 = torch.div(feat_reg_ir, _3)
    _4 = torch.einsum("nlc,nsc->nls", [feat_reg_vi0, feat_reg_ir0])
    conf = torch.div(_4, 0.10000000000000001)
    _5, _6 = torch.max(conf, 2, True)
    mask_forward = torch.to(torch.eq(conf, _5), 6)
    _7, _8 = torch.max(conf, 1, True)
    mask_backward = torch.to(torch.eq(conf, _7), 6)
    mask_mutual = torch.mul(mask_forward, mask_backward)
    _9, j_ids_all = torch.max(mask_mutual, 2)
    _10 = torch.arange(30, dtype=None, layout=None, device=ops.prim.device(img_vi))
    _11 = torch.repeat(torch.view(_10, [-1, 1]), [1, 40])
    y_coords = torch.view(_11, [-1])
    _12 = torch.arange(40, dtype=None, layout=None, device=ops.prim.device(img_vi))
    _13 = torch.repeat(torch.view(_12, [1, -1]), [30, 1])
    x_coords = torch.view(_13, [-1])
    _14 = torch.stack([x_coords, y_coords], 1)
    mkpts0 = torch.mul(torch.to(_14, 6), 8.)
    j_ids = torch.select(j_ids_all, 0, 0)
    j_y = torch.floor_divide(j_ids, 40)
    j_x = torch.sub(j_ids, torch.mul(j_y, 40))
    _15 = [torch.to(j_x, 6), torch.to(j_y, 6)]
    mkpts1 = torch.mul(torch.stack(_15, 1), 8.)
    mask_valid = torch.select(torch.sum(mask_mutual, [2]), 0, 0)
    mask_valid0 = torch.to(torch.gt(mask_valid, 0), 6)
    mkpts0_final = torch.mul(mkpts0, torch.unsqueeze(mask_valid0, 1))
    mkpts1_final = torch.mul(mkpts1, torch.unsqueeze(mask_valid0, 1))
    mkpts0_final0 = torch.to(mkpts0_final, 3)
    mkpts1_final0 = torch.to(mkpts1_final, 3)
    return (mkpts0_final0, mkpts1_final0)
