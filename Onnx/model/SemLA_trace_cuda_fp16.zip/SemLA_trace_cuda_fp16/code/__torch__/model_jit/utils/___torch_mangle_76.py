class DWConv(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  group_conv3x3 : __torch__.torch.nn.modules.conv.___torch_mangle_72.Conv2d
  norm : __torch__.torch.nn.modules.batchnorm.___torch_mangle_73.BatchNorm2d
  act : __torch__.torch.nn.modules.activation.___torch_mangle_74.ReLU
  projection : __torch__.torch.nn.modules.conv.___torch_mangle_75.Conv2d
  def forward(self: __torch__.model_jit.utils.___torch_mangle_76.DWConv,
    argument_1: Tensor) -> Tensor:
    projection = self.projection
    act = self.act
    norm = self.norm
    group_conv3x3 = self.group_conv3x3
    _0 = (group_conv3x3).forward(argument_1, )
    _1 = (act).forward((norm).forward(_0, ), )
    return (projection).forward(_1, )
