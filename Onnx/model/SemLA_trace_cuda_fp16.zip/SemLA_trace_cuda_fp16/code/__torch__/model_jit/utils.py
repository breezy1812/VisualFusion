class DWT_2D(Module):
  __parameters__ = []
  __buffers__ = ["w_ll", "w_lh", "w_hl", "w_hh", ]
  w_ll : Tensor
  w_lh : Tensor
  w_hl : Tensor
  w_hh : Tensor
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.model_jit.utils.DWT_2D,
    argument_1: Tensor) -> Tensor:
    w_hh = self.w_hh
    w_hl = self.w_hl
    w_lh = self.w_lh
    w_ll = self.w_ll
    x = torch.contiguous(argument_1)
    dim = ops.prim.NumToTensor(torch.size(x, 1))
    _0 = int(dim)
    _1 = int(dim)
    _2 = int(dim)
    _3 = torch.expand(w_ll, [int(dim), -1, -1, -1])
    x_ll = torch._convolution(x, _3, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 8, False, False, True, True)
    _4 = torch.expand(w_lh, [_2, -1, -1, -1])
    x_lh = torch._convolution(x, _4, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 8, False, False, True, True)
    _5 = torch.expand(w_hl, [_1, -1, -1, -1])
    x_hl = torch._convolution(x, _5, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 8, False, False, True, True)
    _6 = torch.expand(w_hh, [_0, -1, -1, -1])
    x_hh = torch._convolution(x, _6, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 8, False, False, True, True)
    input = torch.cat([x_ll, x_lh, x_hl, x_hh], 1)
    return input
  def forward1(self: __torch__.model_jit.utils.DWT_2D,
    argument_1: Tensor) -> Tensor:
    w_hh = self.w_hh
    w_hl = self.w_hl
    w_lh = self.w_lh
    w_ll = self.w_ll
    x = torch.contiguous(argument_1)
    dim = ops.prim.NumToTensor(torch.size(x, 1))
    _7 = int(dim)
    _8 = int(dim)
    _9 = int(dim)
    _10 = torch.expand(w_ll, [int(dim), -1, -1, -1])
    x_ll = torch._convolution(x, _10, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 16, False, False, True, True)
    _11 = torch.expand(w_lh, [_9, -1, -1, -1])
    x_lh = torch._convolution(x, _11, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 16, False, False, True, True)
    _12 = torch.expand(w_hl, [_8, -1, -1, -1])
    x_hl = torch._convolution(x, _12, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 16, False, False, True, True)
    _13 = torch.expand(w_hh, [_7, -1, -1, -1])
    x_hh = torch._convolution(x, _13, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 16, False, False, True, True)
    input = torch.cat([x_ll, x_lh, x_hl, x_hh], 1)
    return input
  def forward2(self: __torch__.model_jit.utils.DWT_2D,
    argument_1: Tensor) -> Tensor:
    w_hh = self.w_hh
    w_hl = self.w_hl
    w_lh = self.w_lh
    w_ll = self.w_ll
    x = torch.contiguous(argument_1)
    dim = ops.prim.NumToTensor(torch.size(x, 1))
    _14 = int(dim)
    _15 = int(dim)
    _16 = int(dim)
    _17 = torch.expand(w_ll, [int(dim), -1, -1, -1])
    x_ll = torch._convolution(x, _17, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 32, False, False, True, True)
    _18 = torch.expand(w_lh, [_16, -1, -1, -1])
    x_lh = torch._convolution(x, _18, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 32, False, False, True, True)
    _19 = torch.expand(w_hl, [_15, -1, -1, -1])
    x_hl = torch._convolution(x, _19, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 32, False, False, True, True)
    _20 = torch.expand(w_hh, [_14, -1, -1, -1])
    x_hh = torch._convolution(x, _20, None, [2, 2], [0, 0], [1, 1], False, [0, 0], 32, False, False, True, True)
    input = torch.cat([x_ll, x_lh, x_hl, x_hh], 1)
    return input
class CBR(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv : __torch__.torch.nn.modules.conv.Conv2d
  bn : __torch__.torch.nn.modules.batchnorm.BatchNorm2d
  relu : __torch__.torch.nn.modules.activation.ReLU
  def forward(self: __torch__.model_jit.utils.CBR,
    input: Tensor) -> Tensor:
    relu = self.relu
    bn = self.bn
    conv = self.conv
    _21 = (bn).forward((conv).forward(input, ), )
    return (relu).forward(_21, )
class DWConv(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  group_conv3x3 : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv2d
  norm : __torch__.torch.nn.modules.batchnorm.___torch_mangle_1.BatchNorm2d
  act : __torch__.torch.nn.modules.activation.___torch_mangle_2.ReLU
  projection : __torch__.torch.nn.modules.conv.___torch_mangle_3.Conv2d
  def forward(self: __torch__.model_jit.utils.DWConv,
    argument_1: Tensor) -> Tensor:
    projection = self.projection
    act = self.act
    norm = self.norm
    group_conv3x3 = self.group_conv3x3
    _22 = (group_conv3x3).forward(argument_1, )
    _23 = (act).forward((norm).forward(_22, ), )
    return (projection).forward(_23, )
class MLP(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv1 : __torch__.torch.nn.modules.conv.___torch_mangle_5.Conv2d
  act : __torch__.torch.nn.modules.activation.___torch_mangle_6.ReLU
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_7.Conv2d
  def forward(self: __torch__.model_jit.utils.MLP,
    argument_1: Tensor) -> Tensor:
    conv2 = self.conv2
    act = self.act
    conv1 = self.conv1
    _24 = (act).forward((conv1).forward(argument_1, ), )
    return (conv2).forward(_24, )
class MLP2(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  fc : __torch__.torch.nn.modules.container.___torch_mangle_162.Sequential
  def forward(self: __torch__.model_jit.utils.MLP2,
    argument_1: Tensor) -> Tensor:
    fc = self.fc
    return (fc).forward(argument_1, )
class StructureAttention(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  q_proj : __torch__.torch.nn.modules.linear.___torch_mangle_203.Linear
  k_proj : __torch__.torch.nn.modules.linear.___torch_mangle_204.Linear
  v_proj : __torch__.torch.nn.modules.linear.___torch_mangle_205.Linear
  attention : __torch__.model_jit.utils.LinearAttention
  merge : __torch__.torch.nn.modules.linear.___torch_mangle_206.Linear
  mlp : __torch__.torch.nn.modules.container.___torch_mangle_210.Sequential
  norm1 : __torch__.torch.nn.modules.normalization.___torch_mangle_211.LayerNorm
  norm2 : __torch__.torch.nn.modules.normalization.___torch_mangle_212.LayerNorm
  def forward(self: __torch__.model_jit.utils.StructureAttention,
    x: Tensor) -> Tensor:
    norm2 = self.norm2
    mlp = self.mlp
    norm1 = self.norm1
    merge = self.merge
    attention = self.attention
    v_proj = self.v_proj
    k_proj = self.k_proj
    q_proj = self.q_proj
    bs = ops.prim.NumToTensor(torch.size(x, 0))
    _25 = int(bs)
    _26 = int(bs)
    _27 = int(bs)
    _28 = int(bs)
    input = torch.view((q_proj).forward(x, ), [_28, -1, 8, 32])
    input0 = torch.view((k_proj).forward(x, ), [_27, -1, 8, 32])
    values = torch.view((v_proj).forward(x, ), [_26, -1, 8, 32])
    _29 = (attention).forward(input, input0, values, )
    input1 = torch.view(_29, [_25, -1, 256])
    _30 = (norm1).forward((merge).forward(input1, ), )
    input2 = torch.cat([x, _30], 2)
    _31 = (norm2).forward((mlp).forward(input2, ), )
    return torch.add(x, _31)
  def forward1(self: __torch__.model_jit.utils.StructureAttention,
    x: Tensor) -> Tensor:
    norm2 = self.norm2
    mlp = self.mlp
    norm1 = self.norm1
    merge = self.merge
    attention = self.attention
    v_proj = self.v_proj
    k_proj = self.k_proj
    q_proj = self.q_proj
    bs = ops.prim.NumToTensor(torch.size(x, 0))
    _32 = int(bs)
    _33 = int(bs)
    _34 = int(bs)
    _35 = int(bs)
    input = torch.view((q_proj).forward1(x, ), [_35, -1, 8, 32])
    input3 = torch.view((k_proj).forward1(x, ), [_34, -1, 8, 32])
    values = torch.view((v_proj).forward1(x, ), [_33, -1, 8, 32])
    _36 = (attention).forward1(input, input3, values, )
    input4 = torch.view(_36, [_32, -1, 256])
    _37 = (norm1).forward1((merge).forward1(input4, ), )
    input5 = torch.cat([x, _37], 2)
    _38 = (norm2).forward1((mlp).forward1(input5, ), )
    return torch.add(x, _38)
class LinearAttention(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.model_jit.utils.LinearAttention,
    input: Tensor,
    input6: Tensor,
    values: Tensor) -> Tensor:
    _39 = torch.add(torch.elu(input, 1.), CONSTANTS.c3)
    _40 = torch.to(_39, 5)
    _41 = torch.add(torch.elu(input6, 1.), CONSTANTS.c3)
    K = torch.to(_41, 5)
    v_length = ops.prim.NumToTensor(torch.size(values, 1))
    KV = torch.einsum("nshd,nshv->nhdv", [K, torch.div(values, v_length)])
    _42 = torch.einsum("nlhd,nhd->nlh", [_40, torch.sum(K, [1])])
    _43 = torch.reciprocal(torch.add(_42, CONSTANTS.c4))
    Z = torch.mul(_43, CONSTANTS.c3)
    _44 = torch.to(Z, 5)
    _45 = torch.einsum("nlhd,nhdv,nlh->nlhv", [_40, torch.to(KV, 5), _44])
    queried_values = torch.mul(_45, v_length)
    return torch.contiguous(queried_values)
  def forward1(self: __torch__.model_jit.utils.LinearAttention,
    input: Tensor,
    input7: Tensor,
    values: Tensor) -> Tensor:
    _46 = torch.add(torch.elu(input, 1.), CONSTANTS.c3)
    _47 = torch.to(_46, 5)
    _48 = torch.add(torch.elu(input7, 1.), CONSTANTS.c3)
    K = torch.to(_48, 5)
    v_length = ops.prim.NumToTensor(torch.size(values, 1))
    KV = torch.einsum("nshd,nshv->nhdv", [K, torch.div(values, v_length)])
    _49 = torch.einsum("nlhd,nhd->nlh", [_47, torch.sum(K, [1])])
    _50 = torch.reciprocal(torch.add(_49, CONSTANTS.c4))
    Z = torch.mul(_50, CONSTANTS.c3)
    _51 = torch.to(Z, 5)
    _52 = torch.einsum("nlhd,nhdv,nlh->nlhv", [_47, torch.to(KV, 5), _51])
    queried_values = torch.mul(_52, v_length)
    return torch.contiguous(queried_values)
