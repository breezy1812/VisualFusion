class SemLA_Reg(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  dwt : __torch__.model_jit.utils.DWT_2D
  reg0 : __torch__.model_jit.reg.JConv
  reg1 : __torch__.model_jit.reg.___torch_mangle_22.JConv
  reg2 : __torch__.model_jit.reg.___torch_mangle_37.JConv
  reg3 : __torch__.model_jit.reg.___torch_mangle_52.JConv
  pred_reg : __torch__.torch.nn.modules.container.Sequential
  sa0 : __torch__.model_jit.reg.___torch_mangle_112.JConv
  sa1 : __torch__.model_jit.reg.___torch_mangle_127.JConv
  sa2 : __torch__.model_jit.reg.___torch_mangle_142.JConv
  sa3 : __torch__.model_jit.reg.___torch_mangle_157.JConv
  pred_sa : __torch__.torch.nn.modules.activation.Sigmoid
  csc0 : __torch__.model_jit.reg.CrossModalAttention
  csc1 : __torch__.model_jit.reg.___torch_mangle_172.CrossModalAttention
  ssr : __torch__.model_jit.reg.SemanticStructureRepresentation
  def forward(self: __torch__.model_jit.reg.SemLA_Reg,
    input: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor]:
    ssr = self.ssr
    csc1 = self.csc1
    csc0 = self.csc0
    pred_sa = self.pred_sa
    sa3 = self.sa3
    sa2 = self.sa2
    sa1 = self.sa1
    sa0 = self.sa0
    pred_reg = self.pred_reg
    reg3 = self.reg3
    reg2 = self.reg2
    reg1 = self.reg1
    dwt = self.dwt
    reg0 = self.reg0
    _0 = (dwt).forward((reg0).forward(input, ), )
    _1 = (dwt).forward1((reg1).forward(_0, ), )
    _2 = (dwt).forward2((reg2).forward(_1, ), )
    _3 = (pred_reg).forward((reg3).forward(_2, ), )
    tensor, input0, = torch.split(_3, 1)
    h = ops.prim.NumToTensor(torch.size(_3, 2))
    _4 = int(h)
    w = ops.prim.NumToTensor(torch.size(_3, 3))
    _5 = int(w)
    _6 = (sa1).forward((sa0).forward(input0, ), )
    _7 = (sa3).forward((sa2).forward(_6, ), )
    _8 = (pred_sa).forward(_7, )
    _9 = ops.prim.NumToTensor(torch.size(_8, 0))
    _10 = int(_9)
    _11 = ops.prim.NumToTensor(torch.size(_8, 1))
    _12 = torch.to(torch.view(_8, [_10, int(_11), -1]), 6)
    tensor0 = torch.permute(tensor, [0, 2, 3, 1])
    _13 = torch.contiguous(tensor0)
    _14 = ops.prim.NumToTensor(torch.size(tensor0, 0))
    _15 = int(_14)
    _16 = ops.prim.NumToTensor(torch.size(tensor0, -1))
    _17 = torch.view(_13, [_15, -1, int(_16)])
    feat_reg_vi_flatten_ = torch.to(_17, 6)
    tensor1 = torch.permute(input0, [0, 2, 3, 1])
    _18 = torch.contiguous(tensor1)
    _19 = ops.prim.NumToTensor(torch.size(tensor1, 0))
    _20 = int(_19)
    _21 = ops.prim.NumToTensor(torch.size(tensor1, -1))
    _22 = torch.view(_18, [_20, -1, int(_21)])
    feat_reg_ir_flatten = torch.to(_22, 6)
    _23 = ops.prim.NumToTensor(torch.size(feat_reg_vi_flatten_, 2))
    _24 = torch.div(feat_reg_vi_flatten_, torch.pow(_23, 0.5))
    _25 = ops.prim.NumToTensor(torch.size(feat_reg_ir_flatten, 2))
    _26 = torch.div(feat_reg_ir_flatten, torch.pow(_25, 0.5))
    _27 = torch.einsum("nlc,nsc->nls", [_24, _26])
    attention = torch.div(_27, CONSTANTS.c0)
    _28 = torch.to(torch.softmax(attention, 1), 6)
    attention0 = torch.einsum("nls,ncs->nls", [_28, _12])
    attention1 = torch.to(torch.sum(attention0, [2]), 6)
    _29 = (csc0).forward(feat_reg_vi_flatten_, torch.mul(attention1, CONSTANTS.c2), )
    _30 = (csc1).forward(_29, torch.mul(attention1, CONSTANTS.c2), )
    n = ops.prim.NumToTensor(torch.size(_30, 0))
    _31 = int(n)
    c = ops.prim.NumToTensor(torch.size(_30, 2))
    tensor2 = torch.view(_30, [_31, _4, _5, int(c)])
    input1 = torch.permute(tensor2, [0, 3, 1, 2])
    _32 = (sa1).forward1((sa0).forward1(input1, ), )
    _33 = (sa3).forward1((sa2).forward1(_32, ), )
    _34 = (pred_sa).forward1(_33, )
    _35, _36, = (ssr).forward(_34, _8, )
    tensor3 = torch.add(tensor, _35)
    tensor4 = torch.add(input0, _36)
    _37 = (_34, _8, tensor3, tensor4, _34, _34, _34, _34, _34, _34, _34, _34, _34, _34, _34, _34, _34, _34, _34, _34, _8, _34, _8)
    return _37
class JConv(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  feat_trans : __torch__.model_jit.utils.CBR
  dwconv : __torch__.model_jit.utils.DWConv
  norm : __torch__.torch.nn.modules.batchnorm.___torch_mangle_4.BatchNorm2d
  mlp : __torch__.model_jit.utils.MLP
  def forward(self: __torch__.model_jit.reg.JConv,
    input: Tensor) -> Tensor:
    mlp = self.mlp
    norm = self.norm
    dwconv = self.dwconv
    feat_trans = self.feat_trans
    _38 = (feat_trans).forward(input, )
    input2 = torch.add(_38, (dwconv).forward(_38, ))
    _39 = (mlp).forward((norm).forward(input2, ), )
    return torch.add(input2, _39)
class CrossModalAttention(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  qkv : __torch__.torch.nn.modules.linear.Linear
  proj_out : __torch__.torch.nn.modules.linear.___torch_mangle_158.Linear
  norm1 : __torch__.torch.nn.modules.normalization.LayerNorm
  norm2 : __torch__.torch.nn.modules.normalization.___torch_mangle_159.LayerNorm
  mlp : __torch__.model_jit.utils.MLP2
  def forward(self: __torch__.model_jit.reg.CrossModalAttention,
    feat_reg_vi_flatten_: Tensor,
    argument_2: Tensor) -> Tensor:
    mlp = self.mlp
    norm2 = self.norm2
    proj_out = self.proj_out
    qkv = self.qkv
    norm1 = self.norm1
    _40 = (norm1).forward(feat_reg_vi_flatten_, )
    input = torch.einsum("nl, nlc -> nlc", [argument_2, (qkv).forward(_40, )])
    input3 = torch.add((proj_out).forward(input, ), feat_reg_vi_flatten_)
    _41 = (mlp).forward((norm2).forward(input3, ), )
    return torch.add(input3, _41)
class SemanticStructureRepresentation(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  grid_embedding : __torch__.model_jit.reg.___torch_mangle_187.JConv
  semantic_embedding : __torch__.model_jit.reg.___torch_mangle_202.JConv
  attention : __torch__.model_jit.utils.StructureAttention
  def forward(self: __torch__.model_jit.reg.SemanticStructureRepresentation,
    argument_1: Tensor,
    argument_2: Tensor) -> Tuple[Tensor, Tensor]:
    attention = self.attention
    semantic_embedding = self.semantic_embedding
    grid_embedding = self.grid_embedding
    feat_h = ops.prim.NumToTensor(torch.size(argument_1, 2))
    _42 = int(feat_h)
    feat_w = ops.prim.NumToTensor(torch.size(argument_1, 3))
    _43 = int(feat_w)
    _44 = annotate(number, torch.sub(feat_h, CONSTANTS.c3))
    xs = torch.linspace(0, _44, _42, dtype=None, layout=None, device=torch.device("cpu"), pin_memory=False)
    _45 = annotate(number, torch.sub(feat_w, CONSTANTS.c3))
    ys = torch.linspace(0, _45, _43, dtype=None, layout=None, device=torch.device("cpu"), pin_memory=False)
    _46 = torch.div(xs, torch.sub(feat_h, CONSTANTS.c3))
    _47 = torch.div(ys, torch.sub(feat_w, CONSTANTS.c3))
    _48 = torch.meshgrid([_46, _47], indexing="ij")
    _49, _50, = _48
    _51 = torch.unsqueeze(torch.stack([_49, _50], -1), 0)
    _52 = ops.prim.NumToTensor(torch.size(argument_1, 0))
    _53 = torch.repeat(_51, [int(_52), 1, 1, 1])
    grid = torch.to(_53, torch.device("cpu"), 6)
    h = ops.prim.NumToTensor(torch.size(grid, 1))
    _54 = int(h)
    _55 = int(h)
    w = ops.prim.NumToTensor(torch.size(grid, 2))
    _56 = int(w)
    _57 = int(w)
    input = torch.permute(grid, [0, 3, 1, 2])
    _58 = (grid_embedding).forward(input, )
    input4 = torch.mul(_58, argument_1)
    input5 = torch.mul(_58, argument_2)
    _59 = (semantic_embedding).forward(input4, )
    _60 = (semantic_embedding).forward1(input5, )
    tensor = torch.permute(_59, [0, 2, 3, 1])
    _61 = torch.contiguous(tensor)
    _62 = ops.prim.NumToTensor(torch.size(tensor, 0))
    _63 = int(_62)
    _64 = ops.prim.NumToTensor(torch.size(tensor, -1))
    x = torch.view(_61, [_63, -1, int(_64)])
    tensor5 = torch.permute(_60, [0, 2, 3, 1])
    _65 = torch.contiguous(tensor5)
    _66 = ops.prim.NumToTensor(torch.size(tensor5, 0))
    _67 = int(_66)
    _68 = ops.prim.NumToTensor(torch.size(tensor5, -1))
    x0 = torch.view(_65, [_67, -1, int(_68)])
    _69 = (attention).forward(x, )
    _70 = (attention).forward1(x0, )
    n = ops.prim.NumToTensor(torch.size(_69, 0))
    _71 = int(n)
    c = ops.prim.NumToTensor(torch.size(_69, 2))
    tensor6 = torch.view(_69, [_71, _55, _57, int(c)])
    feat_reg_vi_str = torch.permute(tensor6, [0, 3, 1, 2])
    n0 = ops.prim.NumToTensor(torch.size(_70, 0))
    _72 = int(n0)
    c0 = ops.prim.NumToTensor(torch.size(_70, 2))
    tensor7 = torch.view(_70, [_72, _54, _56, int(c0)])
    feat_reg_ir_str = torch.permute(tensor7, [0, 3, 1, 2])
    return (feat_reg_vi_str, feat_reg_ir_str)
