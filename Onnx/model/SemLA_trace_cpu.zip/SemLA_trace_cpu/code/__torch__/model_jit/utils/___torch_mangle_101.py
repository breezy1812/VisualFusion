class CBR(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv : __torch__.torch.nn.modules.conv.___torch_mangle_98.Conv2d
  bn : __torch__.torch.nn.modules.batchnorm.___torch_mangle_99.BatchNorm2d
  relu : __torch__.torch.nn.modules.activation.___torch_mangle_100.ReLU
  def forward(self: __torch__.model_jit.utils.___torch_mangle_101.CBR,
    input: Tensor) -> Tensor:
    relu = self.relu
    bn = self.bn
    conv = self.conv
    _0 = (bn).forward((conv).forward(input, ), )
    return (relu).forward(_0, )
  def forward1(self: __torch__.model_jit.utils.___torch_mangle_101.CBR,
    input: Tensor) -> Tensor:
    relu = self.relu
    bn = self.bn
    conv = self.conv
    _1 = (bn).forward1((conv).forward1(input, ), )
    return (relu).forward1(_1, )
